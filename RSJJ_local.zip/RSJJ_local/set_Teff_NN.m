function [Teff1, Teff2] = set_Teff_NN(W1, W2 ,N,G1, G2, a1, a2, edges, dep_edges, T, Aij1, Aij2, heat12, heat21)

Teff1 = T*ones(N) + heat12;
Teff2 = T*ones(N) + heat21;

Vij1_mat = abs(W1.*ones(length(W1)) - (W1.*ones(length(W1)))').*Aij1;
Vij2_mat = abs(W2.*ones(length(W2)) - (W2.*ones(length(W2)))').*Aij2;

heat1 = -a1.*G1.*(Vij1_mat.^2);
heat2 = -a2.*G2.*(Vij2_mat.^2);

for idx = 1:length(edges)
   edge = edges(idx);
   curr_dep_edges = dep_edges{idx};
   Teff1(edge) = Teff1(edge) + sum(heat1(curr_dep_edges)); 
   Teff2(edge) = Teff2(edge) + sum(heat2(curr_dep_edges)); 
end


end