%% Superconductivity two layers

% Here we will simulate the coupled case and than compare to the non
% coupled case on the exact same structure

format longEng

tests = 1:1;

R01 = 1 * 8500;
R02 = 1 * 5500;
R0 = 1 * 10000;
eps = 10^-5;
iterNOI1 = 25;
iterNOI = 5*10^3;
Rsmall = 10^-5;
Ico1 = 52*10^-6;
Ico2 = 76*10^-6;
dT = 0.025;
Ti = 1.5;
sigma1 = 0.07;  
sigma2 = 0.04;
Ib = 15 * 10^-6; 
Tmax = 3.0;
Tcmean1 = 2.4; 
Tcmean2 = 2.7; 

a12 = 1.75 * 10^8; %%heating from layer 2 to layer 1
a21 = 1.75 * 10^8; %%heating from layer 1 to layer 2
a1 = a12 * 10^-8; % needed to speed up the convergence within layers
a2 = a21 * 10^-8; % needed to speed up the convergence within layers

% ========================== COMMENT ====================== %
% Notice that a large heating transient is adopted to escape computational minima. 
% A more careful analysis of the ratio between the transient and the
% convergence time would be needed or a NNN parallel thermal scheme
% for more properly updating the local temperatures. 
% =================================================================== %

a1_esc = 3 * 10^7; % escape value for a1
a2_esc = 5 * 10^6; % escape value for a2
transient = 500; % transient time for escaping a minimum

L = 31;
N = L*L + 2;
R1 = 0;
R2 = 0;
W1 = zeros(N,1);
W1(N) = 0;
W2 = zeros(N,1);
W2(N) = 0;

Ib_vec1 = zeros(N-1,1);
Ib_vec1(1) = Ib;
Ib_vec2 = zeros(N-1,1);
Ib_vec2(1) = Ib;

for idx_t = tests

    %% parameters
    C = 1;
    gamma = 2;
    movie_flag = 0;

    %% initialization
    R_heating_coupled_vec1 = [];
    R_heating_coupled_vec2 = [];
    T_heating_coupled_vec = [];
    iter_heating_coupled_vec = [];

    [Ic_zero1, Aij1] = set_Ic_zero(L,N, sigma1);  %% comment this if you want to load
    [Ic_zero2, Aij2] = set_Ic_zero(L,N, sigma2);  %% comment this if you want to load
    
    R_ij1 = R01*Aij1;    %%if you want to go back to fixed value of R0 uncomment this
    R_ij2 = R02*Aij2;    %%if you want to go back to fixed value of R0 uncomment this
    
    % not used
    T01_mean = 1000000000;
    T02_mean = 1000000000;
    T01 = Ic_zero1*T01_mean;
    T02 = Ic_zero2*T02_mean;
    
    Tc1 = Tcmean1*Ic_zero1;
    Tc2 = Tcmean2*Ic_zero2;

    if movie_flag
        v = VideoWriter('newfile.avi');
        open(v);
    end

    flag1 = 0;
    flag2 = 0;
    [edges, dep_edges] = create_dep_NN(L,N);
    
    %% heating coupled
    for T = Ti:dT:Tmax

        epsilon_vec = [];

        for iter = 1:iterNOI1

            if flag1 == 0
                for iter2 = 1:iterNOI

                    if iter2 <= transient
                        a1_escape = a1_esc;
                        a2_escape = a2_esc;
                    else
                        a1_escape = a1; 
                        a2_escape = a2;
                    end

                    [T iter iter2 R1 R2]
                    if iter == 1
                       Teff1 = T;
                    else
                        Vij2_mat = abs(W2.*ones(length(W2)) - (W2.*ones(length(W2)))').*Aij2;
                        %I2 = abs(Vij2_mat.*G2);
                        %heat12 = -a12.*I2.*I2./G2;
                        heat12 = - a12.*G2.*(Vij2_mat.^2);
                        [Teff1, ~] = set_Teff_NN(W1, W2 ,N, G1, G2, a1_escape, a2_escape, edges, dep_edges, T, Aij1, Aij2, heat12, 0);
                    end
                    
                    T_temp1 = (1 - Teff1./Tc1);
                    T_temp1(T_temp1 < 0) = 0;
                    Ic_T1 = Ico1*Ic_zero1.*(T_temp1.^gamma);
                    [G1, state1] = set_G(W1,L,N,R_ij1,Rsmall,Ic_T1, T01, Teff1);
                    G21 = G1(1:N-1, 1:N-1);
                    W_next1 = zeros(N,1);
                    W_next1(1:N-1) = G21\Ib_vec1;
                    W_next1(N) = 0;
                    R1 = W_next1(1)/Ib;
                    W_pre1 = W1;
                    R1pre = W1(1)/Ib;
                    W1 = W_next1;
                    
                    epsilon1 = (norm(W_next1 - W_pre1))/(norm(W_next1));
                    %epsilonR1 = abs(R1pre - R1);
                    %[epsilonR]

                    if epsilon1 < eps
                        break;
                    end
                end

            end


            if flag2 == 0
                for iter2 = 1:iterNOI

                    if iter2 <= transient
                        a1_escape = a1_esc; 
                        a2_escape = a2_esc;
                    else
                        a1_escape = a1; 
                        a2_escape = a2;
                    end

                    [T iter iter2 R1 R2]
                    if iter == 1
                       Teff2 = T;
                    else
                        Vij1_mat = abs(W1.*ones(length(W1)) - (W1.*ones(length(W1)))').*Aij1;
                        %I1 = abs(Vij1_mat.*G1);
                        %heat21 =  -a21.*I1.*I1./G1;
                        heat21 = - a21.*G1.*(Vij1_mat.^2);
                        [~, Teff2] = set_Teff_NN(W1, W2 ,N,G1, G2, a1_escape, a2_escape, edges, dep_edges, T, Aij1, Aij2, 0, heat21);
                    end
                    T_temp2 = (1 - Teff2./Tc2);
                    T_temp2(T_temp2 < 0) = 0;
                    Ic_T2 = Ico2*Ic_zero2.*(T_temp2.^gamma);
                    [G2, state2] = set_G(W2,L,N,R_ij2,Rsmall,Ic_T2, T02, Teff2);
                    G22 = G2(1:N-1, 1:N-1);
                    W_next2 = zeros(N,1);
                    W_next2(1:N-1) = G22\Ib_vec2;
                    W_next2(N) = 0;
                    R2 = W_next2(1)/Ib;
                    W_pre2 = W2;
                    R2pre = W_pre2(1)/Ib;
                    W2 = W_next2;
                    
                    epsilon2 = (norm(W_next2 - W_pre2))/(norm(W_next2)); 
                    %epsilonR2 = abs(R2pre - R2);
                    %[epsilonR2]
                    if epsilon2 < eps
                        break;
                    end 
                end
            end

            if R1 > 1.03*R0 && flag1 == 0
                flag1 = 1;
                Tflag1 = T;
            end

            if R2 > 1.03*R0
                flag2 = 1;
            end

            if flag1 && flag2
                break
            end


            if any(isnan(W_next1)) || any(isnan(W_next2))
                break;
            end

            epsilon = (norm(W_next1 - W_pre1))/(norm(W_next1)) + (norm(W_next2 - W_pre2))/(norm(W_next2)); 
            epsilon_vec = [epsilon_vec epsilon];


            %[T, epsilon, iter]
            %R1

            if epsilon < eps
                break;
            end
        end

        T_heating_coupled_vec = [T_heating_coupled_vec T];
        R_heating_coupled_vec1 = [R_heating_coupled_vec1 R1];
        R_heating_coupled_vec2 = [R_heating_coupled_vec2 R2];
        iter_heating_coupled_vec = [iter_heating_coupled_vec iter];


        %% add frame to the movie
        if movie_flag
            [frame] = set_frame_for_movie_two_layers(L,N,Ti,4.2,R0, state1,  state2, T_heating_vec, R_heating_vec1, R_heating_vec2, [],[],[]);
            writeVideo(v , frame);
            close;
        end


        if flag1 && flag2
            break
        end
    end

    %% cooling coupled
    R1 = R_heating_coupled_vec1(end);
    R2 = R_heating_coupled_vec2(end);
    new_Ti = T;
    R_cooling_coupled_vec1 = [];
    R_cooling_coupled_vec2 = [];
    T_cooling_coupled_vec = [];
    iter_cooling_coupled_vec = [];

    for T = new_Ti:-dT:Ti
        
        epsilon_vec = [];

         for iter = 1:iterNOI1
           
            if T <= new_Ti
                for iter2 = 1:iterNOI

                    if iter2 <= transient
                        a1_escape = a1_esc;
                        a2_escape = a2_esc;
                    else
                        a1_escape = a1; 
                        a2_escape = a2;
                    end

                    [T iter iter2 R1 R2]
                    Vij2_mat = abs(W2.*ones(length(W2)) - (W2.*ones(length(W2)))').*Aij2;
                    %I2 = abs(Vij2_mat.*G2);
                    %heat12 = -a12.*I2.*I2./G2;
                    heat12 = - a12.*G2.*(Vij2_mat.^2);
                    [Teff1, ~] = set_Teff_NN(W1, W2 ,N,G1, G2,a1_escape,a2_escape, edges, dep_edges, T, Aij1, Aij2, heat12, 0);
                    T_temp1 = (1 - Teff1./Tc1);
                    T_temp1(T_temp1 < 0) = 0;
                    Ic_T1 = Ico1*Ic_zero1.*(T_temp1.^gamma);
                    [G1, state1] = set_G(W1,L,N,R_ij1,Rsmall,Ic_T1, T01, Teff1);
                    G21 = G1(1:N-1, 1:N-1);
                    W_next1 = zeros(N,1);
                    W_next1(1:N-1) = G21\Ib_vec1;
                    W_next1(N) = 0;
                    R1 = W_next1(1)/Ib;
                    W_pre1 = W1;
                    R1pre = W_pre1(1)/Ib;
                    W1 = W_next1;

                    epsilon1 = (norm(W_next1 - W_pre1))/(norm(W_next1)); 
                    %epsilonR1 = abs(R1pre - R1);
                    if epsilon1 < eps
                        break;
                    end
                end
            end

            for iter2 = 1:iterNOI

                if iter2 <= transient
                    a1_escape = a1_esc;
                    a2_escape = a1_esc;
                else
                    a1_escape = a1; 
                    a2_escape = a2;
                end

                [T iter iter2 R1 R2]
                Vij1_mat = abs(W1.*ones(length(W1)) - (W1.*ones(length(W1)))').*Aij1;
                %I1 = abs(Vij1_mat.*G1);
                %heat21 =  -a21.*I1.*I1./G1;
                heat21 = - a21.*G1.*(Vij1_mat.^2);
                [~, Teff2] = set_Teff_NN(W1, W2 ,N,G1, G2,a1_escape,a2_escape, edges, dep_edges, T, Aij1, Aij2, 0, heat21);
                T_temp2 = (1 - Teff2./Tc2);
                T_temp2(T_temp2 < 0) = 0;
                Ic_T2 = Ico2*Ic_zero2.*(T_temp2.^gamma);
                [G2, state2] = set_G(W2,L,N,R_ij2,Rsmall,Ic_T2, T02, Teff2);
                G22 = G2(1:N-1, 1:N-1);
                W_next2 = zeros(N,1);
                W_next2(1:N-1) = G22\Ib_vec2;
                W_next2(N) = 0;
                R2 = W_next2(1)/Ib;
                W_pre2 = W2;
                R2pre = W_pre2(1)/Ib;
                W2 = W_next2;

                epsilon2 = (norm(W_next2 - W_pre2))/(norm(W_next2)); 
                %epsilonR2 = abs(R2pre - R2);
                if epsilon2 < eps
                    break;
                end 
            end

            epsilon = (norm(W_next1 - W_pre1))/(norm(W_next1)) + (norm(W_next2 - W_pre2))/(norm(W_next2)); 
            epsilon_vec = [epsilon_vec epsilon];

            if epsilon < eps
                break;
            end
        end

        T_cooling_coupled_vec = [T_cooling_coupled_vec T];
        R_cooling_coupled_vec1 = [R_cooling_coupled_vec1 R1];
        R_cooling_coupled_vec2 = [R_cooling_coupled_vec2 R2];
        iter_cooling_coupled_vec = [iter_cooling_coupled_vec iter];


        %% add frame to the movie
        if movie_flag
            [frame] = set_frame_for_movie_two_layers(L,N,Ti,4.2,R0, state1,  state2, T_heating_vec, R_heating_vec1, R_heating_vec2, T_cooling_vec, R_cooling_vec1, R_cooling_vec2);
            writeVideo(v , frame);
            close;
        end


        if R1 < 10^-3 && R2 < 10^-3
            break
        end
    end

    if movie_flag
        close(v);
    end

    figure(); hold on;
    plot(T_heating_coupled_vec, R_heating_coupled_vec1, '-ro');
    plot(T_heating_coupled_vec, R_heating_coupled_vec2, '-bo');
    plot(T_cooling_coupled_vec, R_cooling_coupled_vec1, '-rs');
    plot(T_cooling_coupled_vec, R_cooling_coupled_vec2, '-bs');
    xlim([Ti,3.0]);
    %ylim([0,1.1]);
    legend('heating layer1','heating layer2','cooling layer1','cooling layer2', 'Location', 'best');
    %title('I_b = 30 \mu A, \sigma = 0.05');
    ylabel('R');
    xlabel('T(K)');

    
filename = ['/Users/ivan_bonamassa/Desktop/final_runs/L31_Ic152Ic276_R185R255_Tc124Tc227_sigma1007sigma2004_G13e7_G25e6_G_175e8_Ib' ,num2str(Ib*(10^6)), '.mat'];
save(filename, 'T_heating_coupled_vec','T_cooling_coupled_vec','R_heating_coupled_vec1','R_heating_coupled_vec2','R_cooling_coupled_vec1','R_cooling_coupled_vec2','T_heating_coupled_vec','T_cooling_coupled_vec','R_heating_coupled_vec1','R_heating_coupled_vec2','R_cooling_coupled_vec1','R_cooling_coupled_vec2');    

end
